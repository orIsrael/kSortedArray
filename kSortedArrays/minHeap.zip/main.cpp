#include "functions.h"

int main()
{
	UI();
	//Pair* arr = new Pair[10];
	//arr[0].priority =10;
	//arr[1].priority = 5;
	//arr[2].priority = 20;
	//arr[3].priority = 1.5;
	//arr[4].priority = -4;
	//arr[5].priority = 8805;
	//arr[6].priority = 29;
	//arr[7].priority = -52;
	//arr[8].priority = 63;
	//arr[9].priority = 69;
	//quickSort(arr, 0, 9);
	//for (int i = 0; i < 10; i++)
	//cout << arr[i].priority<<endl;


}